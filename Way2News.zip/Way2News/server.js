const express = require("express");
const cors = require("cors"); // Add this package
const app = express();
const port = 8000;

// Enable CORS for all routes
app.use(cors());
app.use(express.json());

// Sample live news data
const liveNews = [
  {
    title: "Breaking News: AI Revolution",
    description: "New breakthroughs in AI technology announced today",
    url: "https://news.example.com/ai-revolution",
    published_at: new Date().toISOString()
  },
  {
    title: "New Tech Innovations",
    description: "Latest tech innovations from the Consumer Electronics Show",
    url: "https://news.example.com/tech-innovations",
    published_at: new Date(Date.now() - 3600000).toISOString() // 1 hour ago
  }
];

// Live news endpoint
app.get("/api/live-news", (req, res) => {
  res.json(liveNews);
});

// Login endpoint
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  // Basic validation
  if (email && password) {
    res.json({ 
      token: "sample-token", 
      message: "Login successful (demo)" 
    });
  } else {
    res.status(400).json({ message: "Email and password required" });
  }
});

// Registration endpoint
app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;
  // Basic validation
  if (name && email && password) {
    res.json({ 
      message: "Registration successful (demo)",
      user: { name, email }
    });
  } else {
    res.status(400).json({ message: "All fields are required" });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});